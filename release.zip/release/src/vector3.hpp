#pragma once

struct vector3 {
	float x;
	float y;
	float z;

	vector3(float _x, float _y, float _z) : x(_x), y(_y), z(_z) {}
};