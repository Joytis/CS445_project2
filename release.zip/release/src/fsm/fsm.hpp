#pragma once

#include "enum_class_bitmasks.hpp"
#include "finite_state_system.hpp"
