#pragma once

class basic_shapes {
public:
	static void square();
	static void circle();
};
