// ==============================================================================
// _________               .__    __________      ___.           __
// \_   ___ \  ____   ____ |  |   \______   \ ____\_ |__   _____/  |_ 
// /    \  \/ /  _ \ /  _ \|  |    |       _//  _ \| __ \ /  _ \   __\
// \     \___(  <_> |  <_> )  |__  |    |   (  <_> ) \_\ (  <_> )  |  
//  \______  /\____/ \____/|____/  |____|_  /\____/|___  /\____/|__|  
//         \/                             \/           \/             
// ===============================================================================

Welcome to COOL ROBOT, the rough-n-tumble sequal to the acclaimed title: "Cool Draw".
Unlike its predecessor, Cool Robot requires NO SKILL WHATSOEVER. None. Nothing at all. Nada.
Fortunately, if you're not an artist, then THIS IS THE PROGRAM FOR YOU! Looking for a 
relaxing point-and-click funtime? We've got it. In the form of a robot. Wiggling around.

INSTRUCTIONS:
1. Open up the program.
2. CLICK ON THE CIRCLES! MOVE YOUR MOUSE LEFT AND RIGHT! ROTATE THOSE JOINTS!
3. Watch, attentive, as the robot dances for you.

Now is the time. Use this program! 
